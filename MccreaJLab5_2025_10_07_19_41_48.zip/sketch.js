function setup() {
  createCanvas(400, 400);
    background(220);

}

function draw() {

}

function keyPressed() {
  fill(100,10,10);
  circle(mouseX,mouseY,20)
  
}

function mouseClicked () {
 fill (100,100,100);
  square(mouseX,mouseY,10)

}
