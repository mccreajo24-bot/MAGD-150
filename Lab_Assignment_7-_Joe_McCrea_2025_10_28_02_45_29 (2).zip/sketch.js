
function setup() {
  createCanvas(400, 400);
  background(220);

  let colors = ["Greninja", "Charizard", "Pikachu", "Blastoise","Garchomp" ];
let shapes = ["Inosuke", "Zenitsu", "Tanjiro", "Uzui", "Rengoku"];
let myColors = [];
let myShapes = [];
let both = [];

  for (let i = 0; i < 5; i++) {
let c = floor(random(colors.length));
    myColors.push(colors[c]);
    
both = myColors.concat(myShapes);

    let s = floor(random(shapes.length));
    myShapes.push(shapes[s]);
    shapes.splice(s, 1);
  }
  let r1 = random(myColors);
  let r2 = random(myShapes);
  let rBoth = random(both);

  console.log("Array 1:", myColors);
  console.log("Array 2:", myShapes);
  console.log("Combined Array:", both);

  console.log("Random 1:", r1);
  console.log("Random 2:", r2);
  console.log("Random 1 & 2:", rBoth);

  text("Array 1: " + myColors.join(", "), 10, 10);
  text("Array 2: " + myShapes.join(", "), 10, 20);
  text("Random 1: " + r1, 10, 30);
  text("Random 2: " + r2, 10, 40);
  text("Random 1 & 2: " + rBoth, 10, 50);
}
