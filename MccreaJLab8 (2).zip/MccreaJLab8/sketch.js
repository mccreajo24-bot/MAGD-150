let cloneone;
let clonetwo;

function preload() {
  cloneone = loadImage('/assets/Doomlegion.jpeg');
  clonetwo = loadImage('/assets/Clone.jpeg');
}
function setup() {
  createCanvas(400, 400);
  textSize(60);
  fill(255);//white text
}
function draw() {
  image(cloneone, 0, 0, width, height);
  image(clonetwo, mouseX - 70,200,140,140);
 text('Clone Troopers',20,380);
}
